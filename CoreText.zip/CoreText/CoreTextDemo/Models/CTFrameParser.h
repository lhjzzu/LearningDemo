//
//  CTFrameParser.h
//  CoreTextDemo
//
//  Created by TangQiao on 13-12-7.
//  Copyright (c) 2013年 TangQiao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CoreTextData.h"
#import "CTFrameParserConfig.h"

@interface CTFrameParser : NSObject

+ (CoreTextData *)parseJsonArr:(NSArray *)jsonArray config:(CTFrameParserConfig *)config;
//
+ (NSAttributedString *)parseImageDataFromNSDictionary:(NSDictionary *)dict
                                                config:(CTFrameParserConfig*)config;

//将config转化为字典
+ (NSMutableDictionary *)attributesWithConfig:(CTFrameParserConfig *)config;

//把字符串转化为 CoreTextData
+ (CoreTextData *)parseContent:(NSString *)content config:(CTFrameParserConfig*)config;

//把属性字符串转化为 CoreTextData
+ (CoreTextData *)parseAttributedContent:(NSAttributedString *)content config:(CTFrameParserConfig*)config;

//把json格式的文件转化为 CoreTextData
+ (CoreTextData *)parseTemplateFile:(NSString *)path config:(CTFrameParserConfig*)config;

@end
