//
//  UIWindow+noOperationTime.h
//  Misscandy
//
//  Created by chiyou on 15/8/7.
//  Copyright (c) 2015年 MK. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface UIWindow (noOperationTime)//operate
@end
