//
//  RuntimeCategoryClass.m
//  Category&&Protocol
//
//  Created by 刘华健 on 15/10/27.
//  Copyright © 2015年 MK. All rights reserved.
//

#import "RuntimeCategoryClass.h"

@implementation RuntimeCategoryClass
- (void)method1
{
    
}
@end
