//
//  ViewController.h
//  SendMessageTest
//
//  Created by 刘华健 on 15/10/28.
//  Copyright © 2015年 MK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

