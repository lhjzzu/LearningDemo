//
//  main.m
//  拉伸头部图片
//
//  Created by 刘华健 on 15/7/21.
//  Copyright (c) 2015年 MK. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
