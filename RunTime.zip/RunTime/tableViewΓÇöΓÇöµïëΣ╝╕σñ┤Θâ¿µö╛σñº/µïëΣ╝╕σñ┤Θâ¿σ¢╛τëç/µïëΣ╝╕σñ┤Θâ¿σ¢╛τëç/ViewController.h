//
//  ViewController.h
//  拉伸头部图片
//
//  Created by 刘华健 on 15/7/21.
//  Copyright (c) 2015年 MK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

