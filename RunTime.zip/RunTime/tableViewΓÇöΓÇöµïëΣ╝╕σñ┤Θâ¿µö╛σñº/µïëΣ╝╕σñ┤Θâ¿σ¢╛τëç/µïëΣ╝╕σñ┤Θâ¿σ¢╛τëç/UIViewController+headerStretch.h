//
//  UIViewController+headerStretch.h
//  拉伸头部图片
//
//  Created by 刘华健 on 15/8/13.
//  Copyright (c) 2015年 MK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (headerStretch)
- (void)setHeaderStretchImageView:(UIImageView *)imageView withTableView:(UITableView *)tableView;
@end
