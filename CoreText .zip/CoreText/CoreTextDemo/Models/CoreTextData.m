//
//  CoreTextData.m
//  CoreTextDemo
//
//  Created by TangQiao on 13-12-7.
//  Copyright (c) 2013年 TangQiao. All rights reserved.
//

#import "CoreTextData.h"

@implementation CoreTextData

- (void)setCtFrame:(CTFrameRef)ctFrame {
    if (_ctFrame != ctFrame) {
        if (_ctFrame != nil) {
            CFRelease(_ctFrame);
        }
        CFRetain(ctFrame);
        _ctFrame = ctFrame;
    }
}

- (void)dealloc {
    if (_ctFrame != nil) {
        CFRelease(_ctFrame);
        _ctFrame = nil;
    }
}

- (void)setImageArray:(NSArray *)imageArray {
    _imageArray = imageArray;
    [self fillImagePosition];
}

- (void)fillImagePosition {
    if (self.imageArray.count == 0) {
        return;
    }
    //获取CoreText框架中行的数组
    NSArray *lines = (NSArray *)CTFrameGetLines(self.ctFrame);
    //行数
    NSUInteger lineCount = [lines count];
    NSLog(@"lineCount = %ld",lineCount);
    CGPoint lineOrigins[lineCount];
    //行的起点数组
    CTFrameGetLineOrigins(self.ctFrame, CFRangeMake(0, 0), lineOrigins);
    
    int imgIndex = 0;
    CoreTextImageData * imageData = self.imageArray[0];
    
    NSLog(@"imageArray.count = %ld",self.imageArray.count);
    for (int i = 0; i < lineCount; ++i)
    {
        if (imageData == nil) {
            break;
        }
        //获取每行 CTLineRef
        CTLineRef line = (__bridge CTLineRef)lines[i];
        //获取每行的连续文本（CFRunRef）数组
        NSArray * runObjArray = (NSArray *)CTLineGetGlyphRuns(line);
        for (id runObj in runObjArray)
        {
            //每个连续文本 CTRunRef
            CTRunRef run = (__bridge CTRunRef)runObj;
            //获取连续文本的属性字典
            NSDictionary *runAttributes = (NSDictionary *)CTRunGetAttributes(run);
            NSLog(@"runAttributes == %@",runAttributes);
            //获取连续文本的属性kCTRunDelegateAttributeName对应的值CTRunDelegateRef
            CTRunDelegateRef delegate = (__bridge CTRunDelegateRef)[runAttributes valueForKey:(id)kCTRunDelegateAttributeName];
            if (delegate == nil) {
                continue;
            }
            
            NSDictionary * metaDic = CTRunDelegateGetRefCon(delegate);
            NSLog(@"metaDic == %@",metaDic);
            if (![metaDic isKindOfClass:[NSDictionary class]]) {
                continue;
            }
            
            CGRect runBounds;
            CGFloat ascent;
            CGFloat descent;
            runBounds.size.width = CTRunGetTypographicBounds(run, CFRangeMake(0, 0), &ascent, &descent, NULL);
            runBounds.size.height = ascent + descent;
            
            CGFloat xOffset = CTLineGetOffsetForStringIndex(line, CTRunGetStringRange(run).location, NULL);
            runBounds.origin.x = lineOrigins[i].x + xOffset;
            runBounds.origin.y = lineOrigins[i].y;
            runBounds.origin.y -= descent;
            
            CGPathRef pathRef = CTFrameGetPath(self.ctFrame);
            CGRect colRect = CGPathGetBoundingBox(pathRef);
            
            CGRect delegateBounds = CGRectOffset(runBounds, colRect.origin.x, colRect.origin.y);
            
            imageData.imagePosition = delegateBounds;
            NSLog(@"imagePosition = %@",NSStringFromCGRect(imageData.imagePosition));
            imgIndex++;
            if (imgIndex == self.imageArray.count)
            {
                imageData = nil;
                break;
            } else
            {
                imageData = self.imageArray[imgIndex];
            }
        }
    }
}


@end
