//
//  CoreTextImageData.m
//  CoreTextDemo
//
//  Created by TangQiao on 13-12-8.
//  Copyright (c) 2013年 TangQiao. All rights reserved.
//

#import "CoreTextImageData.h"

@implementation CoreTextImageData

@end
