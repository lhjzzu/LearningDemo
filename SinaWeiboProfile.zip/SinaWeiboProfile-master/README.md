# SinaWeiboProfile
##下拉图片放大 导航栏透明渐变
![样例](http://upload-images.jianshu.io/upload_images/304825-a941a0dcbc587d33.gif?imageView2/2/w/1240)  

[教程地址http://www.jianshu.com/p/a0eb0a55ed31](http://www.jianshu.com/p/a0eb0a55ed31 "教程") 
