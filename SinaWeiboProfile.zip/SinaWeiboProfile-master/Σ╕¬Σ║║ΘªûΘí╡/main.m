//
//  main.m
//  个人首页
//
//  Created by Yahui on 15/7/31.
//  Copyright (c) 2015年 Yahui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
