//
//  ColumnView.h
//  Columns
//
//  Created by Rob Napier on 8/26/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ColumnView : UIView
@property (nonatomic, copy) NSAttributedString *attributedString;
@end
